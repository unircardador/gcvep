package com.rastro2mano.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rastro2mano.modelo.Compra;
import com.rastro2mano.modelo.Usuario;

public interface CompraRepository extends JpaRepository<Compra, Long>{

	List<Compra> findByPropietario(Usuario propietario);
	
}
