package com.rastro2mano.repositorios;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rastro2mano.modelo.Compra;
import com.rastro2mano.modelo.Producto;
import com.rastro2mano.modelo.Usuario;

public interface ProductoRepository extends JpaRepository<Producto, Long>{

	List<Producto> findByPropietario(Usuario propietario);
	
	List<Producto> findByCompra(Compra compra);
	
	List<Producto> findByCompraIsNull();
	
	List<Producto> findByNombreContainsIgnoreCaseAndCompraIsNull(String nombre);
	
	List<Producto> findByNombreContainsIgnoreCaseAndPropietario(String nombre, Usuario propietario);
	
}
