package com.rastro2mano;

import java.awt.Image;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import javax.swing.ImageIcon;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.rastro2mano.modelo.Producto;
import com.rastro2mano.modelo.Usuario;
import com.rastro2mano.servicios.ProductoServicio;
import com.rastro2mano.servicios.UsuarioServicio;
import com.rastro2mano.upload.StorageProperties;
import com.rastro2mano.upload.StorageService;

@SpringBootApplication
public class Rastro2Mano  {

	 
	
	public static void main(String[] args) {
		SpringApplication.run(Rastro2Mano.class, args);
	}

	@Bean
	public CommandLineRunner initData(UsuarioServicio usuarioServicio, ProductoServicio productoServicio) {
		return args -> {
			Usuario admin = new Usuario("Administrador", "Administrador", null, "admin@rastro2mercado.net", "admin");
			admin = usuarioServicio.registrar(admin);
			Usuario usuario = new Usuario("Usuario1", "Usuario1","https://media.istockphoto.com/id/1144287292/es/foto/retrato-a-la-cabeza-de-la-chica-africana-feliz-de-la-raza-mixta-vistiendo-gafas.jpg?s=1024x1024&w=is&k=20&c=NxJSumcFW4RI0OobXQSWPX8Nv4AUbJfX9qEgPN_Qnzo=", "usuario1@rastro2mercado.net", "usuario1");
			usuario = usuarioServicio.registrar(usuario);			
			Usuario usuario2 = new Usuario("Usuario2", "Usuario2", null, "usuario2@rastro2mercado.net", "usuario2");
			usuario2 = usuarioServicio.registrar(usuario2);			
			Usuario usuario3 = new Usuario("Usuario3", "Usuario3", null, "usuario3@rastro2mercado.net", "usuario3");
			usuario3 = usuarioServicio.registrar(usuario3);			
			Usuario usuario4 = new Usuario("Usuario4", "Usuario4", null, "usuario4@rastro2mercado.net", "usuario4");
			usuario4 = usuarioServicio.registrar(usuario4);  
			List<Producto> listado = Arrays.asList(
					new Producto("Bicicleta de montaña", 100.0f,"https://media.istockphoto.com/id/106475987/es/foto/bicicleta-de-monta%C3%B1a.jpg?s=1024x1024&w=is&k=20&c=SXaOVbjfQVdzVh_cZuGdlKvhlN-uoTOGBHAHrjFrdIk=", usuario),
					new Producto("Golf GTI Serie 2", 2500.0f,"https://images.freeimages.com/images/large-previews/2d9/old-jeep-1640347.jpg",usuario),
					new Producto("Raqueta de tenis", 10.5f, "https://m.media-amazon.com/images/I/71aKDg74S1L._AC_SL1500_.jpg", usuario),
					new Producto("Xbox One X", 425.0f, "https://img.pccomponentes.com/articles/32/323080/1144-microsoft-xbox-series-s-512gb.jpg", usuario2),
					new Producto("Trípode flexible", 10.0f, "https://img.pccomponentes.com/articles/25/258471/joby-gorillapod-kit-3k-tripode-flexible-con-rotula-para-camara-d57f9e33-8d24-484e-849d-d5940fd4d054.jpg", usuario2),
					new Producto("Llavero",20.5f,"https://cdn.imprentaonline.net/media/catalog/product/cache/af1f7de92a59ee4a26553b36df22c777/4/0/4034-001-P.jpg",usuario),
					new Producto("Gorra",12.75f,"https://img01.ztat.net/article/spp-media-p1/9d4b14dedd933490b44cc5ffe1b24229/55aff34086754e08919d2aa27b39a0b8.jpg?imwidth=1800",usuario2),
					new Producto("Cuadro Dali",20000f,"https://4.bp.blogspot.com/-Quc6soCAmzk/V9FEuk3M5II/AAAAAAAABrQ/bmh7H2a-AKoKO3PbG4M3OOEPnBf-ZI2IgCLcB/s640/suec3b1o-causado-por-el-vuelo-de-una-abeja-alrededor-de-una-granada-un-segundo-antes-del-despertar-gala-y-tigres.jpg",usuario),
					new Producto("Iphone 7 128 GB", 350.0f, "https://images.freeimages.com/images/large-previews/218/my-dog-cutter-1499799.jpg", usuario2),
					new Producto("Fusible",0.5f,"https://media.istockphoto.com/id/1456037929/es/foto/fusible-el%C3%A9ctrico-rojo-para-autom%C3%B3viles-aislado-sobre-fondo-blanco.jpg?s=1024x1024&w=is&k=20&c=hJonYdRGclSbSFD-ETQSr7g_ixvh8M5RbgOUhSDEgWU=",usuario3),
					new Producto("Destornillador",2.75f,"https://images.freeimages.com/images/large-previews/98f/screw-driver-1414699.jpg",usuario3),
					new Producto("Mesa de madera",1500f,"https://media.istockphoto.com/id/1266344041/es/foto/representaci%C3%B3n-en-3d-de-mesa-de-comedor-de-tablones-de-borde-%C3%A1spero.jpg?s=1024x1024&w=is&k=20&c=icMANHzsSSmu6gHZWPCSQ9LxMCnAnV0LfeOMeM1vGq4=",usuario3),
					new Producto("Vajilla", 50.0f, "https://images.freeimages.com/images/large-previews/81f/catering-soup-plates-1319122.jpg", usuario3));
			
			listado.forEach(productoServicio::insertar);			
		};
	}
	
	/**
	 * Este bean se inicia al lanzar la aplicación. Nos permite inicializar el almacenamiento
	 * secundario del proyecto
	 * 
	 * @param storageService Almacenamiento secundario del proyecto
	 * @return
	 */
	@Bean
    CommandLineRunner init(StorageService storageService) {
        return (args) -> {
            storageService.deleteAll();
            storageService.init();
        };
    }
}
