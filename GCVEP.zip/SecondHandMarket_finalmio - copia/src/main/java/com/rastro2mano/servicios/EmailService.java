package com.rastro2mano.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rastro2mano.modelo.Compra;
import com.rastro2mano.modelo.Email;
import com.rastro2mano.modelo.Usuario;
import com.rastro2mano.repositorios.EmailRepository;

@Service
public class EmailService {

	@Autowired
	EmailRepository repositorio;
	
	public Email insertar(Email e) {
		return repositorio.save(e);
	}
	
	public List<Email> listado(){
		return repositorio.findAll();
	}
	
}
