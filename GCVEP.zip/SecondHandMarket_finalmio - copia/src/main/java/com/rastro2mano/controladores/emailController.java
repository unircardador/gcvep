package com.rastro2mano.controladores;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rastro2mano.repositorios.EmailRepository;

@Controller
public class emailController {

	@Autowired
	EmailRepository repositorio;
	
	@PostMapping("/sendMail")
	public String Email(@RequestParam("name") String nombre, @RequestParam("mail") String email, @RequestParam("movil") String movil, @RequestParam("asunto") String asunto) {
		
		com.rastro2mano.modelo.Email emaila = new com.rastro2mano.modelo.Email(nombre,email,movil,asunto,false);
		repositorio.save(emaila);
		return "contacto";
	}
	
}
